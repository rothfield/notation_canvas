import { loadComposition } from "./io.js";

export let composition = loadComposition();
export let cursorIndexRef = { value: 0 };
