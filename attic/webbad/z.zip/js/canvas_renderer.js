let isSelecting = false;
let selectionStartIndex = null;
let selectionEndIndex = null;
let tokenBoxes = [];

export function handleMouseDown(event, canvas, tokens) {
  const rect = canvas.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;

  isSelecting = true;
  selectionStartIndex = getTokenIndexAt(x, y);
  selectionEndIndex = selectionStartIndex;
}

export function handleMouseMove(event, canvas) {
  if (!isSelecting) return;

  const rect = canvas.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;

  selectionEndIndex = getTokenIndexAt(x, y);
}

export function handleMouseUp() {
  isSelecting = false;
}

function getTokenIndexAt(x, y) {
  for (const box of tokenBoxes) {
    if (
      x >= box.x1 &&
      x <= box.x2 &&
      y >= box.y1 &&
      y <= box.y2
    ) {
      return box.index;
    }
  }
  return null;
}

export function drawComposition(ctx, tokens, cursorIndex) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.font = '20px sans-serif';
  ctx.textBaseline = 'top';

  const lineHeight = 40;
  const padding = 10;
  const maxWidth = ctx.canvas.width - padding * 2;

  let x = padding;
  let y = padding;
  let index = 0;

  const beats = [];
  let currentBeat = [];

  for (const token of tokens) {
    if (token.value === ' ') {
      if (currentBeat.length > 0) {
        beats.push(currentBeat);
        currentBeat = [];
      }
    } else {
      currentBeat.push(token);
    }
  }
  if (currentBeat.length > 0) {
    beats.push(currentBeat);
  }

  tokenBoxes.length = 0;

  for (const beat of beats) {
    const beatStartX = x;
    let beatEndX = x;
    let tokenCount = 0;

    for (const token of beat) {
      const value = token.value;
      const width = ctx.measureText(value).width;

      if (x + width > maxWidth) {
        x = padding;
        y += lineHeight;
      }

      // Highlight selection
      if (
        selectionStartIndex !== null &&
        selectionEndIndex !== null &&
        index >= Math.min(selectionStartIndex, selectionEndIndex) &&
        index <= Math.max(selectionStartIndex, selectionEndIndex)
      ) {
        ctx.fillStyle = 'rgba(180, 200, 255, 0.6)';
        ctx.fillRect(x - 1, y - 2, width + 2, 26);
        ctx.fillStyle = 'black';
      }

      ctx.fillText(value, x, y);

      tokenBoxes.push({
        index,
        x1: x,
        x2: x + width,
        y1: y,
        y2: y + lineHeight
      });

      x += width;
      beatEndX = x;
      tokenCount++;
      index++;
    }

    if (tokenCount > 1) {
      const midX = (beatStartX + beatEndX) / 2;
      const arcHeight = 10;
      ctx.beginPath();
      ctx.moveTo(beatStartX, y + 26);
      ctx.quadraticCurveTo(midX, y + 26 + arcHeight, beatEndX, y + 26);
      ctx.strokeStyle = "black";
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    x += ctx.measureText(' ').width;
    index++;
  }

  if (index === cursorIndex) {
    ctx.fillRect(x - 1, y - 2, 2, 24);
  }
}
