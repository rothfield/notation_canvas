import { drawComposition } from "./canvas_renderer.js";
import { saveCompositionDebounced } from "./io.js";
import { composition, cursorIndexRef, updateAndRender as hook } from "./state.js";
import { handleKeydown, handleClick } from "./editor_input.js";

export function updateAndRender() {
  saveCompositionDebounced(composition);
  renderComposition(composition);
  updateParseTree(composition);
}

hook = updateAndRender;

function renderComposition(comp) {
  const canvas = document.getElementById("notation-canvas");
  const ctx = canvas.getContext("2d");

  const paragraph = comp.paragraphs[0];
  const tokens = paragraph.children.map(el => {
    if (el.type === "note") return { value: el.pitch };
    if (el.type === "space") return { value: " " };
    if (el.type === "barline") return { value: "|" };
    if (el.type === "dash") return { value: "-" };
    return { value: "?" };
  });

  drawComposition(ctx, tokens, cursorIndexRef.value);
}

function updateParseTree(comp) {
  const out = document.getElementById("output-content");
  if (out) {
    out.textContent = JSON.stringify(comp, null, 2);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("notation-canvas");
  canvas.setAttribute("tabindex", "0");
  canvas.focus();

  canvas.addEventListener("keydown", handleKeydown);
  canvas.addEventListener("click", handleClick);

  updateAndRender();
});
