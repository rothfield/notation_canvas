import { loadComposition } from "./io.js";

export let composition = loadComposition();
export let cursorIndexRef = { value: 0 };
export let updateAndRender = () => {
  console.warn("updateAndRender must be assigned by main.js.");
};
