import { lexElement, parseElement } from "../lexer.js";

export function handleKeydown(event, composition, composition.cursorIndex, updateAndRender) {
  console.log(`[handleKeydown] key=${event.key}`);
  const paragraph = composition.paragraphs[0];

  switch (event.key) {
    case "ArrowLeft":
      event.preventDefault();
      handleArrowLeft(composition.cursorIndex);
      break;

    case "ArrowRight":
      event.preventDefault();
      handleArrowRight(paragraph, composition.cursorIndex);
      break;

    case "Backspace":
      event.preventDefault();
      handleBackspace(paragraph, composition.cursorIndex);
      break;

    case "Enter":
      event.preventDefault();
      handleEnterKey(composition, composition.cursorIndex);
      break;

    case "Delete":
      event.preventDefault();
      handleDeleteKey(paragraph, composition.cursorIndex);
      break;

    default:
      insertCharacter(event.key, paragraph, composition.cursorIndex);
  }

  updateAndRender();
}

function handleArrowLeft(composition.cursorIndex) {
  composition.cursorIndex = Math.max(0, composition.cursorIndex - 1);
}

function handleArrowRight(paragraph, composition.cursorIndex) {
  composition.cursorIndex = Math.min(paragraph.children.length, composition.cursorIndex + 1);
}

function handleBackspace(paragraph, composition.cursorIndex) {
  console.log("Backspace key pressed");
  if (composition.cursorIndex > 0) {
    paragraph.children.splice(composition.cursorIndex - 1, 1);
    composition.cursorIndex--;
  }
}

function handleEnterKey(composition, composition.cursorIndex) {
  console.log("Enter key pressed");
}

function handleDeleteKey(paragraph, composition.cursorIndex) {
  console.log("Delete key pressed");
}

function insertCharacter(char, paragraph, composition.cursorIndex) {
  const token = lexElement(char, composition.cursorIndex);
  const element = parseElement(token);
  if (!element) return;

  paragraph.children.splice(composition.cursorIndex, 0, element);
  composition.cursorIndex++;
}
