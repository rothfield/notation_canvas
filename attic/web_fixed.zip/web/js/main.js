import { handleClick } from "./input/handleClick.js";
import { handleKeydown } from "./input/handleKeydown.js";
import { renderComposition } from "./canvas_renderer.js";
import { loadComposition } from "./io.js";

document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("canvas");
  const output = document.getElementById("output-content");

  const cursorIndexRef = { value: 0 };
  const selectionRef = { start: null, end: null };

  function updateAndRender() {
    renderComposition(composition, cursorIndexRef, selectionRef);
    output.textContent = JSON.stringify(composition, null, 2);
  }

  if (!canvas) {
    console.error("Canvas element not found.");
    return;
  }

  canvas.addEventListener("mousedown", (event) =>
    handleClick(event, composition, cursorIndexRef, selectionRef, updateAndRender)
  );

  canvas.addEventListener("keydown", (event) =>
    handleKeydown(event, composition, cursorIndexRef, selectionRef, updateAndRender)
  );

  canvas.setAttribute("tabindex", "0");
  canvas.focus();
  updateAndRender();
});
