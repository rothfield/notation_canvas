
import { selectionRef } from "./state.js";

export function drawComposition(ctx, composition, cursorIndex, xOffset = 10, yOffset = 50) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.font = "20px sans-serif";

  let x = xOffset;

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
  if (!token || typeof token.value !== 'string') continue;
  const { value } = token;
  const width = ctx.measureText(value).width + 4;
  tokens[i].x = x;
  tokens[i].width = width;

    // Highlight if selected
    if (selectionRef.start !== null && selectionRef.end !== null) {
      const selStart = Math.min(selectionRef.start, selectionRef.end);
      const selEnd = Math.max(selectionRef.start, selectionRef.end);
      if (i >= selStart && i <= selEnd) {
        ctx.fillStyle = "#d0eaff";
        ctx.fillRect(x - 2, yOffset - 16, width, 24);
      }
    }

    // Draw note/dash/etc
    ctx.fillStyle = "black";
    ctx.fillText(value, x, yOffset);

    
    
    // Draw bounding box
    ctx.strokeStyle = "rgba(255, 0, 0, 0.3)";
    ctx.strokeRect(x, yOffset - 15, width, 20);

    // Store layout in token
    tokens[i].x = x;
    tokens[i].y = yOffset - 15;
    tokens[i].width = width;
    tokens[i].height = 20;
    // Draw bounding box for visual debug
    ctx.strokeStyle = "rgba(255, 0, 0, 0.3)";
    ctx.strokeRect(x, yOffset - 15, width, 20);

    // Store bounds in the token
    tokens[i].x = x;
    tokens[i].y = yOffset - 15;
    tokens[i].width = width;
    tokens[i].height = 20;
    // Draw cursor
    if (i === cursorIndex) {
      ctx.beginPath();
      ctx.moveTo(x - 1, yOffset - 16);
      ctx.lineTo(x - 1, yOffset + 8);
      ctx.strokeStyle = "red";
      ctx.lineWidth = 1;
      ctx.stroke();

  // Display updated model
  const output = document.getElementById("output-content");
  if (output) {
    output.textContent = JSON.stringify(composition, null, 2);
  }
}

    x += width;
  }
}

function drawSelection(ctx, index, x, width, yOffset) {
  if (selectionRef.start === null || selectionRef.end === null) return;

  const selStart = Math.min(selectionRef.start, selectionRef.end);
  const selEnd = Math.max(selectionRef.start, selectionRef.end);

  if (index >= selStart && index <= selEnd) {
    ctx.fillStyle = "#d0eaff";
    ctx.fillRect(x - 2, yOffset - 16, width, 24);
  }
}
