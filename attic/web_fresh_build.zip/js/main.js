
import { composition, cursorIndexRef, selectionRef } from "./state.js";
import { renderCanvas } from "./canvas_renderer.js";
import { handleKeydown } from "./input/handleKeydown.js";
import { handleClick } from "./input/handleClick.js";

const canvas = document.getElementById("notation-canvas");
const ctx = canvas.getContext("2d");

export function updateAndRender() {
  renderCanvas(composition, ctx, cursorIndexRef.value, selectionRef);
}

canvas.tabIndex = 0;
canvas.addEventListener("keydown", (e) => handleKeydown(e, composition, cursorIndexRef, selectionRef, updateAndRender));
canvas.addEventListener("click", (e) => handleClick(e, composition, cursorIndexRef, selectionRef, updateAndRender));

updateAndRender();
