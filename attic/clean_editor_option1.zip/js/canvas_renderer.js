export function drawComposition(ctx, tokens, cursorIndex) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.font = '20px sans-serif';
  ctx.textBaseline = 'top';

  const lineHeight = 30;
  const padding = 10;
  const maxWidth = ctx.canvas.width - padding * 2;

  let x = padding;
  let y = padding;

  let index = 0;

  const beats = [];
  let currentBeat = [];

  // Split tokens into beats
  for (const token of tokens) {
    if (token.value === ' ') {
      if (currentBeat.length > 0) {
        beats.push(currentBeat);
        currentBeat = [];
      }
    } else {
      currentBeat.push(token);
    }
  }
  if (currentBeat.length > 0) {
    beats.push(currentBeat);
  }

  for (const beat of beats) {
    let text = '';
    let slurStartX = null;
    let slurEndX = null;
    let slurStartY = null;

    const xStart = x;

    for (let i = 0; i < beat.length; i++) {
      const token = beat[i];
      const label = token.value;
      const width = ctx.measureText(label).width;

      // Wrap line
      if (x + width > maxWidth) {
        x = padding;
        y += lineHeight;
      }

      if (label === '(') {
        slurStartX = x;
        slurStartY = y;
      } else if (label === ')') {
        slurEndX = x;
      } else {
        ctx.fillText(label, x, y);

        if (index === cursorIndex) {
          ctx.fillRect(x - 1, y - 2, 2, 24);
        }
      }

      x += width;
      index++;
    }

    // Draw slur arc above
    if (slurStartX !== null && slurEndX !== null) {
      const arcHeight = 10;
      const midX = (slurStartX + slurEndX) / 2;
      ctx.beginPath();
      ctx.moveTo(slurStartX, y - 4);
      ctx.quadraticCurveTo(midX, y - arcHeight - 4, slurEndX, y - 4);
      ctx.strokeStyle = "black";
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    x += ctx.measureText(' ').width;
    index++;
  }

  // Cursor at end
  if (index === cursorIndex) {
    ctx.fillRect(x - 1, y - 2, 2, 24);
  }
}
