
export function handleKeydown(event, composition, cursorIndexRef, selectionRef, updateAndRender) {
  if (event.key === "ArrowRight") {
    cursorIndexRef.value = Math.min(cursorIndexRef.value + 1, composition.paragraphs[0].children.length);
  } else if (event.key === "ArrowLeft") {
    cursorIndexRef.value = Math.max(cursorIndexRef.value - 1, 0);
  }
  updateAndRender();
}
