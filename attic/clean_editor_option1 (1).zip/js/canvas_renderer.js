export function drawComposition(ctx, tokens, cursorIndex) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.font = '20px sans-serif';
  ctx.textBaseline = 'top';

  const lineHeight = 30;
  const padding = 10;
  const maxWidth = ctx.canvas.width - padding * 2;

  let x = padding;
  let y = padding;

  let index = 0;

  const beats = [];
  let currentBeat = [];

  // Split tokens into beats
  for (const token of tokens) {
    if (token.value === ' ') {
      if (currentBeat.length > 0) {
        beats.push(currentBeat);
        currentBeat = [];
      }
    } else {
      currentBeat.push(token);
    }
  }
  if (currentBeat.length > 0) {
    beats.push(currentBeat);
  }

  for (const beat of beats) {
    const text = beat.map(t => t.value).join('');
    const width = ctx.measureText(text).width + 10;

    // Wrap line
    if (x + width > maxWidth) {
      x = padding;
      y += lineHeight;
    }

    // Draw beat
    ctx.fillText(text, x, y);

    // Draw cursor if inside this beat
    for (let i = 0; i < beat.length; i++) {
      if (index === cursorIndex) {
        ctx.fillRect(x - 1, y - 2, 2, 24);
      }
      x += ctx.measureText(beat[i].value).width;
      index++;
    }

    // Add a space between beats
    x += ctx.measureText(' ').width;
    index++; // for the space token
  }

  // Cursor at end
  if (index === cursorIndex) {
    ctx.fillRect(x - 1, y - 2, 2, 24);
  }
}
