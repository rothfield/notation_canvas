import { lexElement, parseElement } from "../lexer.js";

export function handleKeydown(event, composition, cursorIndexRef, updateAndRender) {


function hasSelection(selectionRef) {
  return selectionRef.start !== null && selectionRef.end !== null;
}

function overwriteSelection(paragraph, cursorIndexRef, selectionRef) {
  const selStart = Math.min(selectionRef.start, selectionRef.end);
  const selEnd = Math.max(selectionRef.start, selectionRef.end);
  paragraph.tokens.splice(selStart, selEnd - selStart + 1);
  cursorIndexRef.value = selStart;
  selectionRef.start = null;
  selectionRef.end = null;
}


//
    const selStart = Math.min(selectionRef.start, selectionRef.end);
    const selEnd = Math.max(selectionRef.start, selectionRef.end);
    paragraph.tokens.splice(selStart, selEnd - selStart + 1);
    cursorIndexRef.value = selStart;
    selectionRef.start = null;
    selectionRef.end = null;
    return true;
  }
  return false;
}

  // If a printable character is pressed and a selection exists, delete the selection first
  if (event.key.length === 1 && !event.ctrlKey && !event.metaKey) {
  const paragraph = composition.paragraphs[0];
  if (hasSelection(selectionRef)) {
    overwriteSelection(paragraph, cursorIndexRef, selectionRef);
  }
  const newToken = { value: event.key };
  paragraph.tokens.splice(cursorIndexRef.value, 0, newToken);
  cursorIndexRef.value++;
  event.preventDefault();
  return;
}

  const paragraph = composition.paragraphs[0];
  console.log(`[handleKeydown] key=${event.key}`);
// removed duplicate paragraph declaration

  switch (event.key) {
    case "ArrowLeft":
      if (event.shiftKey) {
        event.preventDefault();
        extendSelection(cursorIndexRef, selectionRef, -1, paragraph.children.length);
      } else {
        event.preventDefault();
        clearSelection(selectionRef);
        cursorIndexRef.value = Math.max(0, cursorIndexRef.value - 1);
      }
      break;

      event.preventDefault();
      handleArrowLeft(cursorIndexRef);
      break;

    case "ArrowRight":
      if (event.shiftKey) {
        event.preventDefault();
        extendSelection(cursorIndexRef, selectionRef, +1, paragraph.children.length);
      } else {
        event.preventDefault();
        clearSelection(selectionRef);
        cursorIndexRef.value = Math.min(paragraph.children.length, cursorIndexRef.value + 1);
      }
      break;

      event.preventDefault();
      handleArrowRight(paragraph, cursorIndexRef);
      break;

    case "Backspace":
      event.preventDefault();
      handleBackspace(paragraph, cursorIndexRef);
      break;

    case "Enter":
      event.preventDefault();
      handleEnterKey(composition, cursorIndexRef);
      break;

    case "Delete":
      event.preventDefault();
      handleDeleteKey(paragraph, cursorIndexRef);
      break;

    default:
      insertCharacter(event.key, paragraph, cursorIndexRef);
  }

  updateAndRender();
}

function handleArrowLeft(cursorIndexRef) {
  cursorIndexRef.value = Math.max(0, cursorIndexRef.value - 1);
}

function handleArrowRight(paragraph, cursorIndexRef) {
  cursorIndexRef.value = Math.min(paragraph.children.length, cursorIndexRef.value + 1);
}

function handleBackspace(paragraph, cursorIndexRef) {
  console.log("Backspace key pressed");
  if (cursorIndexRef.value > 0) {
    paragraph.children.splice(cursorIndexRef.value - 1, 1);
    cursorIndexRef.value--;
  }
}

function handleEnterKey(composition, cursorIndexRef) {
  console.log("Enter key pressed");
}

function handleDeleteKey(paragraph, cursorIndexRef) {
  console.log("Delete key pressed");
}

function insertCharacter(char, paragraph, cursorIndexRef) {
  const token = lexElement(char, cursorIndexRef.value);
  const element = parseElement(token);
  if (!element) return;

  paragraph.children.splice(cursorIndexRef.value, 0, element);
  cursorIndexRef.value++;
}

import { cursorIndexRef, selectionRef } from "../state.js";

function extendSelection(cursorRef, selRef, delta, maxLength) {
  if (selRef.start === null) {
    selRef.start = cursorRef.value;
  }
  cursorRef.value = Math.max(0, Math.min(cursorRef.value + delta, maxLength));
  selRef.end = cursorRef.value;
}

function clearSelection(selRef) {
  selRef.start = null;
  selRef.end = null;
}