
export function renderCanvas(composition, ctx, cursorIndex, selection) {
  if (!composition?.paragraphs?.[0]?.children) return;
  const tokens = composition.paragraphs[0].children;
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.font = "20px sans-serif";
  let x = 10, y = 50;

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    const width = ctx.measureText(token.pitch).width;
    token.x = x;
    token.y = y - 20;
    token.width = width;
    token.height = 24;

    if (selection && selection.start != null && selection.end != null) {
      const selStart = Math.min(selection.start, selection.end);
      const selEnd = Math.max(selection.start, selection.end);
      if (i >= selStart && i < selEnd) {
        ctx.fillStyle = "#cef";
        ctx.fillRect(x, y - 20, width, 24);
      }
    }

    ctx.fillStyle = "black";
    ctx.fillText(token.pitch, x, y);
    x += width;
  }

  if (cursorIndex <= tokens.length) {
    const cx = cursorIndex < tokens.length ? tokens[cursorIndex].x : x;
    ctx.fillRect(cx, y - 18, 2, 20);
  }

  const output = document.getElementById("output-content");
  console.log("Model:", JSON.stringify(composition, null, 2));
  output.textContent = JSON.stringify(composition, null, 2);
}
