let composition = loadComposition();

function updateRawDataDisplay(comp) {
  document.getElementById("raw-data").textContent = JSON.stringify(comp, null, 2);
}

function renderComposition(comp) {
  const output = document.getElementById("html-output");
  output.textContent = ""; // Replace with actual rendering logic
}

function renderHTML(comp) {
  document.getElementById("html-raw").textContent = "<composition>...</composition>";
}

function updateAndRender() {
  saveCompositionDebounced();
  renderComposition(composition);
  updateRawDataDisplay(composition);
  renderHTML(composition);
}

window.addEventListener("DOMContentLoaded", () => {
  updateAndRender();
});
