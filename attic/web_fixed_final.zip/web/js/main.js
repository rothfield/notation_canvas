import { composition } from "./state.js";
import { renderComposition } from "./canvas_renderer.js";
import { handleClick } from "./input/handleClick.js";
import { handleKeydown } from "./input/handleKeydown.js";
import { handleClick } from "./input/handleClick.js";
import { handleKeydown } from "./input/handleKeydown.js";
import { renderComposition } from "./canvas_renderer.js";
import { loadComposition } from "./io.js";

document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("canvas");
  const output = document.getElementById("output-content");


  function updateAndRender() {
    output.textContent = JSON.stringify(composition, null, 2);
  }

  if (!canvas) {
    console.error("Canvas element not found.");
    return;
  }

  canvas.addEventListener("mousedown", (event) =>
  );

  canvas.addEventListener("keydown", (event) =>
  );

  canvas.setAttribute("tabindex", "0");
  canvas.focus();
  updateAndRender();
});
